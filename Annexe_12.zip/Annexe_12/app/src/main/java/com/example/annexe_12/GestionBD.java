package com.example.annexe_12;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.lang.reflect.Array;
import java.util.ArrayList;

//C'est un singleton car on a besoin d'un seul objet de ce type pour tout le projet
public class GestionBD extends SQLiteOpenHelper {
    private static GestionBD instance; //référence à lui-même
    private SQLiteDatabase database;

    public static GestionBD getInstance(Context contexte) {
        if (instance == null)
            instance = new GestionBD(contexte);
        return instance;
    }

    //le constructeur doit être privé car singleton
    private  GestionBD(@Nullable Context context) {
        //le contexte, le nom de la db, pour une fabrique de curseurs, la version de notre db
        super(context, "annexe12", null, 1);

        //ou on aurait pu le faire dans le onCreate de l'activité
        ouvrirConnexionBD();
    }

    //il est exécuté une seule fois lorsqu'on installe l'app sur un téléphone
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventeur ("+
                    "_id            INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "Nom            TEXT," +
                    "Origine        TEXT," +
                    "Invention      TEXT," +
                    "Annee          INTEGER" +
                    ")" );
        ajouterInventeur(new Inventeur("Laszlo Biro",        "Hongrie",      "Stylo à bille",    1938), db);
        ajouterInventeur(new Inventeur("Benjamin Franklin",  "Etats-Unis",   "Paratonnerre",     1752), db);
        ajouterInventeur(new Inventeur("Mary Anderson",      "Etats-Unis",   "Essuie-glace",     1903), db);
        ajouterInventeur(new Inventeur("Grace Hopper",       "Etats-Unis",   "Compilateur",      1952), db);
        ajouterInventeur(new Inventeur("Benoit Rouquayrot",  "France",       "Scaphandre",       1864), db);
    }

    public void ajouterInventeur( Inventeur i, SQLiteDatabase db ){
        //ContentValues un peu comme une hashmap
        ContentValues cv = new ContentValues();
        cv.put("Nom", i.getNom());
        cv.put("Origine", i.getOrigine());
        cv.put("Invention", i.getInvention());
        cv.put("Annee", i.getAnnee());
        db.insert("inventeur", null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE if EXISTS inventeur");
    }

    public void ouvrirConnexionBD(){
        database = this.getWritableDatabase();
    }

    public ArrayList<String> retournerInventions() {
        ArrayList<String> listeInventions = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT invention FROM inventeur", null );
        while (cursor.moveToNext()){
            listeInventions.add(cursor.getString(0));
        }
        cursor.close();
        return listeInventions;
    }

    public boolean aBonneReponse ( String nom, String invention){
        String[] parametres = {nom,invention};
        Cursor c = database.rawQuery("SELECT Nom, Invention FROM inventeur WHERE Nom = ? AND Invention = ?", parametres);
        boolean reponse = c.moveToFirst();
        c.close();
        return reponse;
    }

}
